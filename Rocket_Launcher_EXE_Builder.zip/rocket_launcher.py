"""Rocket Launcher - rocket-themed Windows game library.

Keeps compatibility with the existing games.json format. Optional fields added:
  arguments: command-line arguments passed to the game

Install: py -m pip install -r requirements_launcher.txt
Run:     py rocket_launcher.py
Build:   run build_rocket_launcher.bat on Windows with a PyInstaller-supported Python version.
"""
from __future__ import annotations

import datetime
import json
import os
import re
import shutil
import queue
import shlex
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
import webbrowser
from io import BytesIO
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog

import customtkinter as ctk
from PIL import Image, ImageDraw, ImageFont, ImageOps

APP_NAME = "Rocket Launcher"
# When frozen, store games.json and covers next to the EXE, not in the temporary bundle.
BASE_DIR = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
RESOURCE_DIR = Path(getattr(sys, "_MEIPASS", BASE_DIR))
DATA_FILE = BASE_DIR / "games.json"
COVER_DIR = BASE_DIR / "covers"
SETTINGS_FILE = BASE_DIR / "rocket_launcher_settings.json"
COVER_SIZE = (190, 285)
COLUMNS = 2
# Tactical armory palette
BG = "#0d100f"
SIDEBAR_BG = "#101411"
CARD_BG = "#191e19"
CARD_HOVER = "#252d22"
ACCENT = "#36f04a"
ACCENT_HOVER = "#65ff70"
MUTED = "#a5b19f"
STAR = "#8eea4f"
PANEL = "#151a15"
BORDER = "#3b4a32"

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")


def load_games():
    """Read legacy games.json and normalize entries without dropping extra fields."""
    try:
        with DATA_FILE.open("r", encoding="utf-8-sig") as handle:
            data = json.load(handle)
    except FileNotFoundError:
        return []
    except (json.JSONDecodeError, OSError) as exc:
        messagebox.showwarning("Library couldn't be loaded", f"{DATA_FILE.name} could not be read. Your original file has not been overwritten.\n\n{exc}")
        return []
    if not isinstance(data, list):
        messagebox.showwarning("Library format problem", "games.json should contain a list of games. The original file has not been overwritten.")
        return []
    result, seen = [], set()
    for index, raw in enumerate(data):
        if not isinstance(raw, dict) or not str(raw.get("name", "")).strip() or not str(raw.get("path", "")).strip():
            continue
        game = dict(raw)
        game["id"] = str(game.get("id") or f"legacy-{index}-{time.time_ns()}")
        while game["id"] in seen:
            game["id"] += "x"
        seen.add(game["id"])
        game["name"] = str(game["name"]).strip()
        game["path"] = str(game["path"])
        game.setdefault("cover", None)
        game.setdefault("arguments", "")
        try:
            game["seconds"] = max(0, float(game.get("seconds", 0) or 0))
        except (TypeError, ValueError):
            game["seconds"] = 0
        try:
            game["last_played"] = float(game["last_played"]) if game.get("last_played") else None
        except (TypeError, ValueError):
            game["last_played"] = None
        result.append(game)
    return result


def save_games(games, parent=None):
    """Atomic save, with a backup of the previous library when possible."""
    temp_path = DATA_FILE.with_suffix(".json.tmp")
    backup_path = DATA_FILE.with_suffix(".json.bak")
    try:
        BASE_DIR.mkdir(parents=True, exist_ok=True)
        if DATA_FILE.exists():
            try:
                backup_path.write_bytes(DATA_FILE.read_bytes())
            except OSError:
                pass
        with temp_path.open("w", encoding="utf-8") as handle:
            json.dump(games, handle, indent=2, ensure_ascii=False)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, DATA_FILE)
        return True
    except OSError as exc:
        try:
            temp_path.unlink(missing_ok=True)
        except OSError:
            pass
        messagebox.showerror("Couldn't save library", f"Your changes could not be saved.\n\n{exc}", parent=parent)
        return False


def format_time(seconds):
    seconds = max(0, int(seconds or 0))
    if seconds == 0:
        return "Not played yet"
    hours, remainder = divmod(seconds, 3600)
    minutes = remainder // 60
    return f"{hours}h {minutes}m played" if hours else (f"{minutes}m played" if minutes else "Less than 1m played")


def format_last_played(timestamp):
    if not timestamp:
        return ""
    try:
        played = datetime.date.fromtimestamp(float(timestamp))
        days = (datetime.date.today() - played).days
    except (ValueError, TypeError, OSError, OverflowError):
        return ""
    if days <= 0:
        return "Last played today"
    if days == 1:
        return "Last played yesterday"
    if days < 30:
        return f"Last played {days} days ago"
    return "Last played " + played.strftime("%b %d, %Y")


def download_cover(name, game_id):
    COVER_DIR.mkdir(parents=True, exist_ok=True)
    headers = {"User-Agent": "MyGameLauncher/4.0"}
    url = "https://store.steampowered.com/api/storesearch/?" + urllib.parse.urlencode({"term": name, "l": "english", "cc": "US"})
    request = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(request, timeout=10) as response:
        data = json.load(response)
    items = [item for item in data.get("items", []) if item.get("type") == "app"]
    if not items:
        return None
    app_id = items[0].get("id")
    if not app_id:
        return None
    image_url = f"https://cdn.cloudflare.steamstatic.com/steam/apps/{app_id}/library_600x900.jpg"
    with urllib.request.urlopen(urllib.request.Request(image_url, headers=headers), timeout=15) as response:
        image_bytes = response.read()
    with Image.open(BytesIO(image_bytes)) as image:
        image.verify()
    path = COVER_DIR / f"{game_id}.jpg"
    path.write_bytes(image_bytes)
    return str(path)


class GameEditor(ctk.CTkToplevel):
    def __init__(self, master, game=None, on_save=None):
        super().__init__(master)
        self.master_app = master
        self.original = game
        self.on_save = on_save
        self.title("Edit mission" if game else "Add game to Rocket Launcher")
        self.geometry("650x420")
        self.minsize(560, 390)
        self.configure(fg_color=BG)
        self.transient(master)
        self.grab_set()
        self.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(self, text="MISSION DETAILS", font=self.master_app.make_font(size=22, weight="bold")).grid(row=0, column=0, columnspan=3, sticky="w", padx=24, pady=(22, 18))
        self.name_var = ctk.StringVar(value=(game or {}).get("name", ""))
        self.path_var = ctk.StringVar(value=(game or {}).get("path", ""))
        self.args_var = ctk.StringVar(value=(game or {}).get("arguments", ""))
        self.cover_var = ctk.StringVar(value=(game or {}).get("cover") or "")
        self._field(1, "Game name", self.name_var)
        self._field(2, "Executable / launcher", self.path_var, browse="exe")
        self._field(3, "Launch arguments", self.args_var, placeholder="Optional, e.g. -windowed")
        self._field(4, "Cover image", self.cover_var, browse="image")
        ctk.CTkLabel(self, text="Arguments are passed to the selected executable. Store shortcuts can be added using their registered URL protocols.", text_color=MUTED, wraplength=580, justify="left").grid(row=5, column=0, columnspan=3, sticky="w", padx=24, pady=(8, 14))
        ctk.CTkButton(self, text="Cancel", fg_color="transparent", border_width=1, command=self.destroy).grid(row=6, column=1, sticky="e", padx=(0, 10), pady=18)
        ctk.CTkButton(self, text="Save game", fg_color=ACCENT, hover_color=ACCENT_HOVER, command=self.save).grid(row=6, column=2, sticky="e", padx=(0, 24), pady=18)
        self.bind("<Escape>", lambda _event: self.destroy())

    def _field(self, row, label, variable, browse=None, placeholder=None):
        ctk.CTkLabel(self, text=label, text_color=MUTED).grid(row=row, column=0, sticky="w", padx=(24, 12), pady=7)
        entry = ctk.CTkEntry(self, textvariable=variable, placeholder_text=placeholder or "")
        entry.grid(row=row, column=1, sticky="ew", padx=4, pady=7)
        if browse:
            command = self.browse_exe if browse == "exe" else self.browse_image
            ctk.CTkButton(self, text="Browse", width=82, command=command).grid(row=row, column=2, padx=(8, 24), pady=7)
        else:
            ctk.CTkLabel(self, text="", width=82).grid(row=row, column=2, padx=(8, 24))

    def browse_exe(self):
        path = filedialog.askopenfilename(parent=self, title="Select executable or launcher", filetypes=[("Programs", "*.exe *.bat *.cmd"), ("All files", "*.*")])
        if path:
            self.path_var.set(path)
            if not self.name_var.get().strip():
                self.name_var.set(Path(path).stem)

    def browse_image(self):
        path = filedialog.askopenfilename(parent=self, title="Select cover image", filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.bmp")])
        if path:
            self.cover_var.set(path)

    def save(self):
        name, path = self.name_var.get().strip(), self.path_var.get().strip()
        if not name or not path:
            messagebox.showwarning("Missing information", "Enter both a game name and executable/launcher path.", parent=self)
            return
        if not Path(path).exists() and not path.lower().startswith(("steam://", "com.epicgames.launcher://")):
            if not messagebox.askyesno("Path not found", "This path does not currently exist. Save it anyway?", parent=self):
                return
        game = dict(self.original or {})
        game.update({"id": game.get("id") or str(time.time_ns()), "name": name, "path": path, "arguments": self.args_var.get().strip(), "cover": self.cover_var.get().strip() or None})
        game.setdefault("seconds", 0)
        game.setdefault("last_played", None)
        if self.on_save:
            self.on_save(game, self.original)
        self.destroy()


class Launcher(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        try:
            self.icon_src = Image.open(RESOURCE_DIR / "rocket_launcher_icon.png").convert("RGBA")
        except Exception:
            self.icon_src = Image.new("RGBA", (64, 64), (20, 25, 20, 255))
        self.brand_icon_image = ctk.CTkImage(light_image=self.icon_src, dark_image=self.icon_src, size=(38, 38))
        # Apply the user's custom Rocket Launcher icon on Windows.
        icon_resource = RESOURCE_DIR / "rocket_launcher.ico"
        icon_path = BASE_DIR / "rocket_launcher.ico"
        if icon_resource.is_file() and not icon_path.is_file() and getattr(sys, "frozen", False):
            try:
                shutil.copy2(icon_resource, icon_path)
            except OSError:
                icon_path = icon_resource
        if os.name == "nt" and icon_path.is_file():
            try:
                self.iconbitmap(default=str(icon_path))
            except Exception:
                pass
        self.geometry("1320x880")
        self.minsize(1040, 680)
        self.configure(fg_color=BG)
        self.games = load_games()
        self.running = {}  # game id -> (process, monotonic start time)
        self.play_buttons = {}
        self.cover_cache = {}
        self.fetching = set()
        self.misses = []
        self.results = queue.Queue()
        self.store_results = queue.Queue()
        self.view = "library"
        self.console_mode = False
        self.console_frame = None
        self.console_cards = []
        self.console_games = []
        self.console_index = 0
        self.controller = None
        self._controller_prev = set()
        self._controller_hat_prev = (0, 0)
        self._controller_axis_prev = (0, 0)
        self._controller_last_move_at = 0.0
        self.settings = self.load_settings()
        self.settings.setdefault("font_family", "Segoe UI")
        self.settings.setdefault("collections", {})
        self.settings.setdefault("play_next", None)
        if not isinstance(self.settings.get("collections"), dict):
            self.settings["collections"] = {}
        self.create_desktop_shortcut_once()
        self.wallpaper_image = None
        self.wallpaper_label = None
        self.animation_phase = 0
        self._apply_wallpaper()
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)
        self.build_sidebar()
        self.build_main()
        self.set_view("library")
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.after(500, self.tick)
        self.after(120, self.animate_ui)
        # Scan installed Steam/Epic games immediately after the UI is ready.
        self.after(250, self.auto_scan_installed_games)

    def make_font(self, size=12, weight="normal"):
        """Create a UI font using the currently selected family."""
        family = getattr(self, "settings", {}).get("font_family", "Segoe UI")
        return ctk.CTkFont(family=family, size=size, weight=weight)

    def open_settings(self):
        win = ctk.CTkToplevel(self)
        win.title("Rocket Launcher — Settings")
        win.geometry("470x300")
        win.resizable(False, False)
        win.configure(fg_color=BG)
        win.transient(self)
        win.grab_set()

        ctk.CTkLabel(win, text="LAUNCHER SETTINGS", font=self.make_font(22, "bold"),
                     text_color="#eef5e9").pack(anchor="w", padx=26, pady=(24, 4))
        ctk.CTkLabel(win, text="Choose the typeface used throughout Rocket Launcher.",
                     font=self.make_font(12), text_color=MUTED).pack(anchor="w", padx=26, pady=(0, 20))

        current = self.settings.get("font_family", "Segoe UI")
        font_var = ctk.StringVar(value=current)
        ctk.CTkLabel(win, text="FONT FAMILY", font=self.make_font(10, "bold"),
                     text_color=STAR).pack(anchor="w", padx=28, pady=(0, 6))
        font_menu = ctk.CTkOptionMenu(
            win, variable=font_var,
            values=["Segoe UI", "Arial", "Bahnschrift", "Aptos", "Trebuchet MS", "Consolas"],
            width=390, height=40, fg_color="#1c2519", button_color=ACCENT,
            button_hover_color=ACCENT_HOVER)
        font_menu.pack(padx=26, anchor="w")
        preview = ctk.CTkLabel(win, text="ROCKET LAUNCHER  •  READY FOR DEPLOYMENT",
                               font=ctk.CTkFont(family=current, size=15, weight="bold"),
                               text_color=ACCENT)
        preview.pack(anchor="w", padx=28, pady=22)
        font_var.trace_add("write", lambda *_: preview.configure(
            font=ctk.CTkFont(family=font_var.get(), size=15, weight="bold")))

        buttons = ctk.CTkFrame(win, fg_color="transparent")
        buttons.pack(fill="x", padx=26, pady=(8, 20))
        ctk.CTkButton(buttons, text="Cancel", width=110, fg_color="transparent",
                      border_width=1, command=win.destroy).pack(side="right", padx=(8, 0))
        def apply_font():
            self.settings["font_family"] = font_var.get()
            self.save_settings()
            win.destroy()
            # Rebuild the main widgets so every existing label/button uses the new font.
            for child in self.winfo_children():
                child.destroy()
            self.wallpaper_image = None
            self.wallpaper_label = None
            self._apply_wallpaper()
            self.columnconfigure(1, weight=1)
            self.rowconfigure(0, weight=1)
            self.build_sidebar()
            self.build_main()
            self.set_view(self.view)
            self.after(120, self.animate_ui)
        ctk.CTkButton(buttons, text="Apply font", width=130, fg_color=ACCENT,
                      hover_color=ACCENT_HOVER, command=apply_font).pack(side="right")
        win.bind("<Escape>", lambda _event: win.destroy())

    def load_settings(self):
        try:
            with SETTINGS_FILE.open("r", encoding="utf-8") as f:
                settings = json.load(f)
            return settings if isinstance(settings, dict) else {}
        except (OSError, json.JSONDecodeError):
            return {}

    def save_settings(self):
        try:
            SETTINGS_FILE.write_text(json.dumps(self.settings, indent=2), encoding="utf-8")
        except OSError as exc:
            messagebox.showwarning("Settings", f"Could not save settings: {exc}", parent=self)

    def create_desktop_shortcut_once(self):
        """Create a Desktop shortcut to the run script on the first Windows launch."""
        if os.name != "nt" or self.settings.get("desktop_shortcut_created"):
            return
        run_script = BASE_DIR / "Run_Rocket_Launcher.bat"
        if not run_script.is_file():
            return
        # Use Windows' own shortcut COM object; no extra Python package is required.
        def ps_quote(value):
            return str(value).replace("'", "''")
        command = (
            "$desktop = [Environment]::GetFolderPath('Desktop'); "
            "$shell = New-Object -ComObject WScript.Shell; "
            f"$shortcut = $shell.CreateShortcut((Join-Path $desktop '{APP_NAME}.lnk')); "
            f"$shortcut.TargetPath = '{ps_quote(run_script)}'; "
            f"$shortcut.WorkingDirectory = '{ps_quote(BASE_DIR)}'; "
            "$shortcut.Description = 'Launch Rocket Launcher'; "
            f"$shortcut.IconLocation = '{ps_quote(BASE_DIR / 'rocket_launcher.ico')},0'; "
            "$shortcut.Save()"
        )
        try:
            result = subprocess.run(
                ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", command],
                capture_output=True, text=True, timeout=12, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
            )
            if result.returncode == 0:
                self.settings["desktop_shortcut_created"] = True
                self.save_settings()
        except (OSError, subprocess.SubprocessError):
            # Don't block startup if Windows policy prevents shortcut creation.
            pass

    def _apply_wallpaper(self):
        # Use the bundled tactical texture by default; a custom wallpaper takes priority.
        custom_path = self.settings.get("wallpaper")
        path = custom_path if custom_path and os.path.isfile(custom_path) else str(BASE_DIR / "rocket_nebula.png")
        if not os.path.isfile(path):
            return
        try:
            image = Image.open(path).convert("RGB")
            self.wallpaper_image = ctk.CTkImage(ImageOps.fit(image, (1600, 1000)), size=(1600, 1000))
            self.wallpaper_label = ctk.CTkLabel(self, text="", image=self.wallpaper_image, fg_color="transparent")
            self.wallpaper_label.place(x=200, y=0, relwidth=1, relheight=1)
            self.wallpaper_label.lower()
        except Exception:
            if custom_path:
                self.settings.pop("wallpaper", None)

    def build_sidebar(self):
        sidebar = ctk.CTkFrame(self, width=218, corner_radius=0, fg_color=SIDEBAR_BG,
                               border_width=1, border_color="#303a2a")
        sidebar.grid(row=0, column=0, sticky="ns")
        sidebar.grid_propagate(False)

        self.brand_icon_image = ctk.CTkImage(light_image=self.icon_src, dark_image=self.icon_src, size=(38, 38))
        ctk.CTkLabel(sidebar, text="  ROCKET LAUNCHER", image=self.brand_icon_image,
                     compound="left", font=self.make_font(size=18, weight="bold"),
                     text_color="#eef5e9").pack(padx=12, pady=(22, 0), anchor="w")
        ctk.CTkLabel(sidebar, text="GAME LAUNCHER", font=self.make_font(size=11, weight="bold"),
                     text_color=ACCENT).pack(padx=22, pady=(2, 25), anchor="w")

        self.nav_buttons = {}
        for key, label in (("library", "◈   Game Library"), ("recent", "◷   Recent Games")):
            button = ctk.CTkButton(sidebar, text=label, anchor="w", height=43, corner_radius=10,
                                   fg_color="transparent", hover_color=CARD_HOVER,
                                   command=lambda k=key: self.set_view(k))
            button.pack(fill="x", padx=12, pady=3)
            self.nav_buttons[key] = button

        ctk.CTkButton(sidebar, text="☄  Store Hub / Accounts", anchor="w", fg_color=ACCENT, hover_color=ACCENT_HOVER, command=self.open_store_hub).pack(fill="x", padx=12, pady=(8, 3))
        ctk.CTkButton(sidebar, text="▤  Collections / Play Next", anchor="w", fg_color="#1c2519", hover_color="#303f27", border_width=1, border_color=STAR, command=self.open_collections).pack(fill="x", padx=12, pady=(5, 3))
        ctk.CTkButton(sidebar, text="🎮  Console Mode", anchor="w", fg_color="#1c2519", hover_color="#303f27", border_width=1, border_color=STAR, command=self.enter_console_mode).pack(fill="x", padx=12, pady=(5, 3))

        ctk.CTkLabel(sidebar, text="LAUNCH SYSTEMS", font=self.make_font(size=10, weight="bold"),
                     text_color=MUTED).pack(padx=21, pady=(30, 8), anchor="w")
        ctk.CTkButton(sidebar, text="↗  Steam", anchor="w", fg_color=CARD_BG, hover_color=CARD_HOVER,
                      command=lambda: self.open_uri("steam://open/main")).pack(fill="x", padx=12, pady=3)
        ctk.CTkButton(sidebar, text="↗  Epic Games", anchor="w", fg_color=CARD_BG, hover_color=CARD_HOVER,
                      command=lambda: self.open_uri("com.epicgames.launcher://apps")).pack(fill="x", padx=12, pady=3)
        ctk.CTkButton(sidebar, text="↗  GOG Galaxy website", anchor="w", fg_color=CARD_BG, hover_color=CARD_HOVER,
                      command=lambda: webbrowser.open("https://www.gog.com/galaxy")).pack(fill="x", padx=12, pady=3)

        ctk.CTkLabel(sidebar, text="ARMORY TOOLS", font=self.make_font(size=10, weight="bold"),
                     text_color=MUTED).pack(padx=21, pady=(30, 8), anchor="w")
        ctk.CTkButton(sidebar, text="▦  Set tactical wallpaper", anchor="w", fg_color="transparent",
                      hover_color=CARD_HOVER, command=self.set_wallpaper).pack(fill="x", padx=12, pady=3)
        ctk.CTkButton(sidebar, text="◌  Clear wallpaper", anchor="w", fg_color="transparent",
                      hover_color=CARD_HOVER, command=self.clear_wallpaper).pack(fill="x", padx=12, pady=3)
        ctk.CTkButton(sidebar, text="⚙  Settings", anchor="w", fg_color="transparent",
                      hover_color=CARD_HOVER, command=self.open_settings).pack(fill="x", padx=12, pady=3)
        ctk.CTkLabel(sidebar, text="■  READY FOR DEPLOYMENT", text_color="#65725b",
                     font=self.make_font(size=10, weight="bold")).pack(side="bottom", anchor="w", padx=20, pady=20)

    def build_main(self):
        main = ctk.CTkFrame(self, fg_color="transparent")
        main.grid(row=0, column=1, sticky="nsew", padx=25, pady=20)
        main.columnconfigure(0, weight=1)
        main.rowconfigure(4, weight=1)

        hero = ctk.CTkFrame(main, fg_color="#1a2118", corner_radius=22, height=150,
                            border_width=1, border_color="#3a4a2d")
        hero.grid(row=0, column=0, sticky="ew", pady=(0, 18))
        hero.grid_columnconfigure(0, weight=1)
        hero.grid_propagate(False)
        self.hero_banner = hero
        ctk.CTkFrame(hero, width=4, fg_color=ACCENT, corner_radius=3).place(x=0, y=20, relheight=0.72)
        hero_text = ctk.CTkFrame(hero, fg_color="transparent")
        hero_text.grid(row=0, column=0, sticky="w", padx=24, pady=21)
        ctk.CTkLabel(hero_text, text="ROCKET LAUNCHER  /  TACTICAL COMMAND",
                     font=self.make_font(size=10, weight="bold"), text_color=STAR).pack(anchor="w", pady=(0, 5))
        ctk.CTkLabel(hero_text, text="YOUR ARSENAL. YOUR RULES.",
                     font=self.make_font(size=28, weight="bold"), text_color="#eef5e9").pack(anchor="w")
        ctk.CTkLabel(hero_text, text="SYSTEM READY  •  CHOOSE YOUR NEXT DEPLOYMENT",
                     font=self.make_font(size=10, weight="bold"), text_color="#b6c0aa").pack(anchor="w", pady=(6, 0))
        self.hero_rocket_label = ctk.CTkLabel(hero, image=ctk.CTkImage(light_image=self.icon_src, dark_image=self.icon_src, size=(70, 70)), text="")
        self.hero_rocket_label.place(relx=0.79, rely=0.25, anchor="center")
        self.hero_status_label = ctk.CTkLabel(hero, text="● SYSTEM ONLINE",
                     font=self.make_font(size=10, weight="bold"), text_color="#72f0bd")
        self.hero_status_label.place(relx=0.88, rely=0.76, anchor="center")

        stats = ctk.CTkFrame(main, fg_color="transparent")
        stats.grid(row=1, column=0, sticky="ew", pady=(0, 18))
        for i in range(3): stats.grid_columnconfigure(i, weight=1)
        self.stat_games = self._stat_tile(stats, 0, "LIBRARY", "0 GAMES", STAR)
        total_hours = sum(float(g.get("seconds", 0) or 0) for g in self.games) / 3600
        self.stat_hours = self._stat_tile(stats, 1, "PLAY TIME", f"{total_hours:.1f} HRS", "#a6ed6c")
        self.stat_recent = self._stat_tile(stats, 2, "GAMES RUNNING", f"{len(self.running)} RUNNING", "#72f0bd")

        top = ctk.CTkFrame(main, fg_color="transparent")
        top.grid(row=2, column=0, sticky="ew")
        self.title_label = ctk.CTkLabel(top, text="Game Library", font=self.make_font(size=25, weight="bold"), text_color="#f4f7ff")
        self.title_label.pack(side="left")
        ctk.CTkButton(top, text="＋  Add Game", fg_color=ACCENT, hover_color=ACCENT_HOVER,
                      height=38, corner_radius=11, font=self.make_font(size=12, weight="bold"), command=self.add_game).pack(side="right")
        ctk.CTkButton(top, text="✦  Find Covers", fg_color="#172740", hover_color="#223956",
                      height=38, corner_radius=11, command=self.fetch_missing_covers).pack(side="right", padx=10)

        tools = ctk.CTkFrame(main, fg_color="transparent")
        tools.grid(row=3, column=0, sticky="ew", pady=(14, 12))
        self.search_entry = ctk.CTkEntry(tools, placeholder_text="⌕   Search your game library…", width=310, height=39,
                                         corner_radius=11, border_color="#2b4261", fg_color="#0c1423")
        self.search_entry.pack(side="left")
        self.search_entry.bind("<KeyRelease>", lambda _event: self.render())
        self.sort_var = ctk.StringVar(value="Name (A-Z)")
        ctk.CTkOptionMenu(tools, variable=self.sort_var, values=["Name (A-Z)", "Most played", "Recently played"],
                          command=lambda _choice: self.render(), height=39, corner_radius=10,
                          fg_color="#172740", button_color=ACCENT, button_hover_color=ACCENT_HOVER).pack(side="left", padx=12)
        self.status_label = ctk.CTkLabel(tools, text="", text_color=MUTED, font=self.make_font(size=11))
        self.status_label.pack(side="left", padx=8)
        self.grid_frame = ctk.CTkScrollableFrame(main, fg_color="transparent", corner_radius=14,
                           scrollbar_button_color="#3b4a32", scrollbar_button_hover_color=ACCENT)
        self.grid_frame.grid(row=4, column=0, sticky="nsew")

    def enter_console_mode(self):
        if self.console_mode:
            return
        self.console_mode = True
        self._normal_geometry = self.geometry()
        self._normal_state = self.state()
        self.attributes("-fullscreen", True)
        self.console_frame = ctk.CTkFrame(self, fg_color="#0d100f", corner_radius=0)
        self.console_frame.place(relx=0, rely=0, relwidth=1, relheight=1)
        self.console_frame.grid_columnconfigure(0, weight=1)
        self.console_frame.grid_rowconfigure(1, weight=1)
        header = ctk.CTkFrame(self.console_frame, fg_color="transparent")
        header.grid(row=0, column=0, sticky="ew", padx=38, pady=(25, 8))
        ctk.CTkLabel(header, text="ROCKET LAUNCHER  /  CONSOLE MODE", text_color=STAR,
                     font=self.make_font(size=22, weight="bold")).pack(side="left")
        ctk.CTkLabel(header, text="D-PAD / STICK: BROWSE     A / ENTER: PLAY     B / ESC: EXIT",
                     text_color="#b6c0aa", font=self.make_font(size=12, weight="bold")).pack(side="right")
        self.console_body = ctk.CTkScrollableFrame(self.console_frame, fg_color="transparent")
        self.console_body.grid(row=1, column=0, sticky="nsew", padx=28, pady=8)
        self.console_body.grid_columnconfigure((0, 1), weight=1, uniform="console")
        footer = ctk.CTkFrame(self.console_frame, fg_color="transparent")
        footer.grid(row=2, column=0, sticky="ew", padx=38, pady=(5, 22))
        self.console_status = ctk.CTkLabel(footer, text="Controller support: checking…", text_color=MUTED)
        self.console_status.pack(side="left")
        ctk.CTkButton(footer, text="EXIT CONSOLE  [ESC / B]", width=210, height=44,
                      fg_color=ACCENT, hover_color=ACCENT_HOVER, command=self.exit_console_mode).pack(side="right")
        self.console_index = 0
        self.render_console_games()
        self.bind_all("<Left>", lambda e: self.console_move(-1, 0) if self.console_mode else None)
        self.bind_all("<Right>", lambda e: self.console_move(1, 0) if self.console_mode else None)
        self.bind_all("<Up>", lambda e: self.console_move(0, -1) if self.console_mode else None)
        self.bind_all("<Down>", lambda e: self.console_move(0, 1) if self.console_mode else None)
        self.bind_all("<Return>", lambda e: self.console_launch_selected() if self.console_mode else None)
        self.bind_all("<Escape>", lambda e: self.exit_console_mode() if self.console_mode else None)
        self.bind_all("<a>", lambda e: self.console_move(-1, 0) if self.console_mode else None)
        self.bind_all("<d>", lambda e: self.console_move(1, 0) if self.console_mode else None)
        self.bind_all("<w>", lambda e: self.console_move(0, -1) if self.console_mode else None)
        self.bind_all("<s>", lambda e: self.console_move(0, 1) if self.console_mode else None)
        self.init_controller()
        self.after(60, self.poll_controller)

    def render_console_games(self):
        for child in self.console_body.winfo_children():
            child.destroy()
        self.console_cards = []
        play_id = str(self.settings.get("play_next") or "")
        self.console_games = sorted(self.games, key=lambda g: (str(g.get("id")) != play_id, str(g.get("name", "")).casefold()))
        if not self.console_games:
            ctk.CTkLabel(self.console_body, text="NO GAMES DETECTED\nAuto-scan your PC in desktop mode, then return to your command deck.",
                         text_color=MUTED, font=self.make_font(size=24, weight="bold")).grid(row=0, column=0, columnspan=2, pady=100)
            return
        for i, game in enumerate(self.console_games):
            row, col = divmod(i, 2)
            card = ctk.CTkFrame(self.console_body, fg_color="#191e19", corner_radius=18,
                                border_width=3, border_color=STAR if i == self.console_index else "#34305c")
            card.grid(row=row, column=col, padx=12, pady=12, sticky="nsew")
            card.bind("<Button-1>", lambda e, idx=i: self.console_select(idx))
            cover = ctk.CTkLabel(card, text="", image=self.get_cover(game))
            cover.pack(padx=12, pady=(12, 8))
            cover.bind("<Button-1>", lambda e, idx=i: self.console_select(idx))
            ctk.CTkLabel(card, text=game.get("name", "Untitled"), text_color="#eef5e9",
                         font=self.make_font(size=16, weight="bold"), wraplength=220).pack(padx=8, pady=(0, 4))
            is_uninstalled = game.get("store") == "epic" and not game.get("installed", False)
            is_next = str(game.get("id")) == str(self.settings.get("play_next") or "")
            ctk.CTkLabel(card, text="★ PLAY NEXT" if is_next else ("INSTALL" if is_uninstalled else "PRESS A / ENTER TO PLAY"),
                         text_color=STAR, font=self.make_font(size=10, weight="bold")).pack(pady=(0, 12))
            self.console_cards.append(card)
        self.update_console_selection()

    def console_select(self, index):
        self.console_index = max(0, min(index, len(self.console_games)-1))
        self.update_console_selection()

    def update_console_selection(self):
        for i, card in enumerate(self.console_cards):
            card.configure(border_color=ACCENT if i == self.console_index else "#34305c",
                           fg_color="#20291d" if i == self.console_index else "#191e19")
        if self.console_games:
            game = self.console_games[self.console_index]
            self.console_status.configure(text=f"{self.console_index+1} / {len(self.console_games)}  •  {game.get('name','')}  •  " + ("Controller connected" if self.controller else "Keyboard works too"))

    def console_move(self, dx, dy):
        if not self.console_games:
            return
        columns = 2
        col = self.console_index % columns
        row = self.console_index // columns
        rows = (len(self.console_games) + columns - 1) // columns
        col = (col + dx) % columns if dx else col
        row = max(0, min(rows-1, row + dy)) if dy else row
        candidate = min(row * columns + col, len(self.console_games)-1)
        self.console_select(candidate)
        try:
            self.console_cards[self.console_index].focus_set()
        except Exception:
            pass

    def console_launch_selected(self):
        if self.console_games:
            self.play(self.console_games[self.console_index])

    def init_controller(self):
        try:
            import pygame
            pygame.init()
            pygame.joystick.init()
            count = pygame.joystick.get_count()
            if count:
                # Prefer the first attached device and clear stale input state after reconnecting.
                self.controller = pygame.joystick.Joystick(0)
                self.controller.init()
                self._controller_prev = set()
                self._controller_hat_prev = (0, 0)
                self._controller_axis_prev = (0, 0)
                self._controller_last_move_at = 0.0
                self.console_status.configure(text=f"Controller connected: {self.controller.get_name()} · A/Cross plays · B/Circle exits")
            else:
                self.controller = None
                self.console_status.configure(text="No controller detected · connect it now, or use arrows + Enter")
        except Exception as exc:
            self.controller = None
            self.console_status.configure(text=f"Controller support unavailable: {exc} · use arrows + Enter")

    def poll_controller(self):
        if not self.console_mode:
            return
        try:
            import pygame
            pygame.event.pump()
            count = pygame.joystick.get_count()
            attached = False
            if self.controller is not None:
                try:
                    attached = bool(self.controller.get_init()) and (not hasattr(self.controller, "get_attached") or self.controller.get_attached())
                except Exception:
                    attached = False
            if not attached and count:
                self.init_controller()
                attached = self.controller is not None
            if attached and self.controller is not None:
                joy = self.controller
                buttons = {i for i in range(joy.get_numbuttons()) if joy.get_button(i)}
                just_pressed = buttons - self._controller_prev
                self._controller_prev = buttons
                hat = joy.get_hat(0) if joy.get_numhats() else (0, 0)
                axes = [0, 0]
                # Most XInput pads use axes 0/1; some controllers expose a hat only.
                if joy.get_numaxes() >= 2:
                    axes = [-1 if joy.get_axis(0) < -0.50 else 1 if joy.get_axis(0) > 0.50 else 0,
                            -1 if joy.get_axis(1) < -0.50 else 1 if joy.get_axis(1) > 0.50 else 0]
                # Many inexpensive controllers report the D-pad as four ordinary buttons.
                dpad = (0, 0)
                if joy.get_numbuttons() > 14:
                    if joy.get_button(13): dpad = (-1, 0)
                    elif joy.get_button(14): dpad = (1, 0)
                    elif joy.get_button(11): dpad = (0, -1)
                    elif joy.get_button(12): dpad = (0, 1)
                if hat != (0, 0):
                    move = (hat[0], -hat[1])  # pygame hats report up as +1
                else:
                    move = dpad if dpad != (0, 0) else tuple(axes)  # axes/buttons report down as +1
                oldmove = self._controller_hat_prev
                now = time.monotonic()
                # Move immediately on a new direction, then repeat while held for console-style navigation.
                if move != (0, 0) and (oldmove == (0, 0) or move != oldmove or now - self._controller_last_move_at >= 0.22):
                    self.console_move(move[0], move[1])
                    self._controller_last_move_at = now
                self._controller_hat_prev = move
                if 0 in just_pressed:
                    self.console_launch_selected()  # common Xbox A / PlayStation Cross mapping
                if 1 in just_pressed:
                    self.exit_console_mode()         # common Xbox B / PlayStation Circle mapping
                if 4 in just_pressed and self.console_games:
                    self.console_select((self.console_index - 1) % len(self.console_games))  # LB: previous
                if 5 in just_pressed and self.console_games:
                    self.console_select((self.console_index + 1) % len(self.console_games))  # RB: next
            elif not count:
                self.controller = None
                self._controller_prev = set()
                self.console_status.configure(text="Controller disconnected · reconnect it or use arrows + Enter")
        except Exception as exc:
            try:
                self.console_status.configure(text=f"Controller input error: {exc}")
            except Exception:
                pass
        if self.console_mode:
            self.after(45, self.poll_controller)

    def exit_console_mode(self):
        if not self.console_mode:
            return
        self.console_mode = False
        try:
            self.unbind_all("<Left>"); self.unbind_all("<Right>")
            self.unbind_all("<Up>"); self.unbind_all("<Down>")
            self.unbind_all("<Return>"); self.unbind_all("<Escape>")
            self.unbind_all("<a>"); self.unbind_all("<d>")
            self.unbind_all("<w>"); self.unbind_all("<s>")
        except Exception:
            pass
        if self.console_frame is not None:
            self.console_frame.destroy()
            self.console_frame = None
        self.attributes("-fullscreen", False)
        try:
            self.geometry(self._normal_geometry)
            self.state(self._normal_state)
        except Exception:
            pass
        if self.controller:
            try: self.controller.quit()
            except Exception: pass
            self.controller = None
        try:
            import pygame
            pygame.joystick.quit()
            pygame.quit()
        except Exception:
            pass

    def _stat_tile(self, parent, column, label, value, accent):
        tile = ctk.CTkFrame(parent, fg_color="#0d1627", corner_radius=13,
                            border_width=1, border_color="#1c2d46", height=62)
        tile.grid(row=0, column=column, sticky="ew", padx=(0 if column == 0 else 7, 7 if column < 2 else 0))
        tile.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(tile, text=label, text_color="#8499b8",
                     font=self.make_font(size=9, weight="bold")).grid(row=0, column=0, sticky="w", padx=13, pady=(9, 0))
        value_label = ctk.CTkLabel(tile, text=value, text_color=accent,
                                   font=self.make_font(size=15, weight="bold"))
        value_label.grid(row=1, column=0, sticky="w", padx=13, pady=(0, 8))
        return value_label

    def animate_ui(self):
        """Small, low-cost motion accents; animation stays on Tk's UI thread."""
        try:
            import math
            self.animation_phase = (self.animation_phase + 1) % 120
            phase = self.animation_phase / 120.0
            x = 0.73 + 0.13 * (0.5 - 0.5 * math.cos(phase * 2 * math.pi))
            y = 0.27 + 0.025 * math.sin(phase * 2 * math.pi)
            self.hero_rocket_label.place_configure(relx=x, rely=y)
            self.hero_status_label.configure(text_color="#72f0bd" if self.animation_phase % 30 < 15 else "#3fae91")
            if self.winfo_exists(): self.after(80, self.animate_ui)
        except Exception:
            return

    def set_view(self, view):
        self.view = view
        self.title_label.configure(text="Game Library" if view == "library" else "Recent Missions")
        for key, button in self.nav_buttons.items():
            button.configure(fg_color=ACCENT if key == view else "transparent")
        self.render()

    def visible_games(self):
        games = list(self.games)
        query = self.search_entry.get().strip().casefold()
        if query:
            games = [g for g in games if query in str(g.get("name", "")).casefold()]
        if self.view == "recent":
            games = [g for g in games if g.get("last_played")]
            games.sort(key=lambda g: g.get("last_played") or 0, reverse=True)
        elif self.sort_var.get() == "Most played":
            games.sort(key=lambda g: g.get("seconds", 0), reverse=True)
        elif self.sort_var.get() == "Recently played":
            games.sort(key=lambda g: g.get("last_played") or 0, reverse=True)
        else:
            games.sort(key=lambda g: str(g.get("name", "")).casefold())
        return games

    def render(self):
        if hasattr(self, "stat_games"):
            self.stat_games.configure(text=f"{len(self.games)} GAMES")
            total_hours = sum(float(g.get("seconds", 0) or 0) for g in self.games) / 3600
            self.stat_hours.configure(text=f"{total_hours:.1f} HRS")
            self.stat_recent.configure(text=f"{len(self.running)} RUNNING")
        for widget in self.grid_frame.winfo_children():
            widget.destroy()
        self.play_buttons.clear()
        games = self.visible_games()
        if not games:
            text = 'Your launchpad is empty. Open Store Hub to connect Steam/Epic or click “＋ Add Game”.' if not self.games else ('Games you launch will appear here.' if self.view == "recent" and not self.search_entry.get().strip() else "No games match your search.")
            ctk.CTkLabel(self.grid_frame, text=text, text_color=MUTED).grid(row=0, column=0, padx=60, pady=60)
            return
        for col in range(COLUMNS):
            self.grid_frame.grid_columnconfigure(col, weight=1, uniform="game_cards")
        for index, game in enumerate(games):
            self.make_card(game, index // COLUMNS, index % COLUMNS)

    def make_placeholder_cover(self, game):
        """Create a designed, game-title placeholder instead of a blank gray poster."""
        width, height = COVER_SIZE
        image = Image.new("RGB", (width, height), (10, 10, 28))
        draw = ImageDraw.Draw(image)
        # Tactical graphite background with olive frame and the user's supplied launcher icon.
        for y in range(height):
            t = y / max(1, height - 1)
            color = (int(13 + 5*t), int(16 + 5*t), int(14 + 3*t))
            draw.line((0, y, width, y), fill=color)
        draw.rectangle((9, 9, width-10, height-10), outline=(77, 110, 49), width=2)
        try:
            brand = Image.open(RESOURCE_DIR / "rocket_launcher_icon.png").convert("RGBA")
            brand.thumbnail((112, 92), Image.Resampling.LANCZOS)
            image.paste(brand, ((width-brand.width)//2, 44), brand)
        except Exception:
            draw.rectangle((width//2-40, 55, width//2+40, 110), outline=(54, 240, 74), width=2)
        try:
            font = ImageFont.truetype("arial.ttf", 17)
            small = ImageFont.truetype("arial.ttf", 10)
        except OSError:
            font, small = ImageFont.load_default(), ImageFont.load_default()
        title = str(game.get("name", "UNKNOWN GAME")).strip().upper()
        words, lines, line = title.split(), [], ""
        for word in words:
            candidate = (line + " " + word).strip()
            if draw.textbbox((0, 0), candidate, font=font)[2] <= width - 28:
                line = candidate
            else:
                if line: lines.append(line)
                line = word
        if line: lines.append(line)
        lines = lines[:4]
        y = 170 if len(lines) <= 2 else 153
        for text_line in lines:
            box = draw.textbbox((0, 0), text_line, font=font)
            draw.text(((width-(box[2]-box[0]))/2, y), text_line, font=font, fill=(245, 248, 255))
            y += 24
        draw.text((17, height-35), "ROCKET LAUNCHER  //  GAME FILE", font=small, fill=(142, 234, 79))
        return image

    def get_cover(self, game):
        gid = game["id"]
        if gid not in self.cover_cache:
            try:
                path = game.get("cover")
                if not path or not os.path.isfile(path):
                    raise FileNotFoundError
                with Image.open(path) as source:
                    picture = ImageOps.fit(source.convert("RGB"), COVER_SIZE)
            except Exception:
                picture = self.make_placeholder_cover(game)
            self.cover_cache[gid] = ctk.CTkImage(light_image=picture, dark_image=picture, size=COVER_SIZE)
        return self.cover_cache[gid]

    def make_card(self, game, row, col):
        gid = game["id"]
        card = ctk.CTkFrame(self.grid_frame, corner_radius=16, fg_color=CARD_BG,
                            border_width=1, border_color="#3a4931")
        card.grid(row=row, column=col, padx=9, pady=10, sticky="ew")
        card.bind("<Enter>", lambda _e, w=card: self._card_hover(w, True))
        card.bind("<Leave>", lambda _e, w=card: self._card_hover(w, False))
        cover_wrap = ctk.CTkFrame(card, fg_color="#0d110e", corner_radius=13,
                                  border_width=2, border_color=STAR)
        cover_wrap.pack(padx=10, pady=(12, 9))
        cover_label = ctk.CTkLabel(cover_wrap, image=self.get_cover(game), text="")
        cover_label.pack(padx=4, pady=4)
        cover_label.bind("<Enter>", lambda _e, w=card: self._card_hover(w, True))
        cover_label.bind("<Leave>", lambda _e, w=card: self._card_hover(w, False))
        ctk.CTkLabel(card, text=game.get("name", "Untitled"), font=self.make_font(size=14, weight="bold"),
                     wraplength=COVER_SIZE[0], height=36, text_color="#eef5e9").pack(padx=8)
        ctk.CTkLabel(card, text=format_time(game.get("seconds", 0)), text_color="#9eac96",
                     font=self.make_font(size=11)).pack(pady=(0, 1))
        last = format_last_played(game.get("last_played"))
        if last: ctk.CTkLabel(card, text=last, text_color="#7c8a75", font=self.make_font(size=10)).pack()
        is_epic_uninstalled = game.get("store") == "epic" and not game.get("installed", False)
        action_text = "●  IN FLIGHT…" if gid in self.running else ("⬇  INSTALL" if is_epic_uninstalled else "▶  LAUNCH")
        play = ctk.CTkButton(card, text=action_text, state="disabled" if gid in self.running else "normal",
                             fg_color=ACCENT, hover_color=ACCENT_HOVER, height=36, corner_radius=10,
                             font=self.make_font(size=11, weight="bold"), command=lambda g=game: self.play(g))
        play.pack(padx=10, pady=(10, 7), fill="x")
        self.play_buttons[gid] = play
        actions = ctk.CTkFrame(card, fg_color="transparent")
        actions.pack(padx=8, pady=(0, 10), fill="x")
        actions.grid_columnconfigure((0, 1, 2), weight=1)
        for label, command, column in (("EDIT", lambda g=game: self.edit_game(g), 0),
                                       ("FOLDER", lambda g=game: self.open_game_folder(g), 1),
                                       ("REMOVE", lambda g=game: self.remove_game(g), 2)):
            ctk.CTkButton(actions, text=label, height=27, corner_radius=8,
                          font=self.make_font(size=9, weight="bold"), fg_color="#151a15",
                          hover_color="#35452d", border_width=1, border_color="#35452d",
                          command=command).grid(row=0, column=column, padx=2, sticky="ew")
        extra = ctk.CTkFrame(card, fg_color="transparent")
        extra.pack(fill="x", padx=8, pady=(0, 10))
        extra.grid_columnconfigure((0, 1), weight=1)
        ctk.CTkButton(extra, text="＋ ADD TO COLLECTION", height=28, corner_radius=8,
                      font=self.make_font(size=9, weight="bold"), fg_color="#252d22", hover_color="#35452d",
                      command=lambda g=game: self.add_to_collection(g)).grid(row=0, column=0, padx=2, sticky="ew")
        is_play_next = str(self.settings.get("play_next") or "") == str(gid)
        ctk.CTkButton(extra, text="★ PLAY NEXT" if is_play_next else "☆ PLAY NEXT", height=28, corner_radius=8,
                      font=self.make_font(size=9, weight="bold"), fg_color="#354b25" if is_play_next else "#252d22",
                      hover_color="#405b2c", command=lambda g=game: self.set_play_next(g)).grid(row=0, column=1, padx=2, sticky="ew")

    def _card_hover(self, card, hovered):
        try:
            card.configure(fg_color=CARD_HOVER if hovered else CARD_BG,
                           border_color=ACCENT if hovered else "#3a4931")
        except Exception:
            pass

    def _collections(self):
        collections = self.settings.setdefault("collections", {})
        # Normalize persisted collection data and remove stale IDs without deleting games.
        valid_ids = {str(g.get("id")) for g in self.games}
        for name, ids in list(collections.items()):
            if not isinstance(ids, list):
                collections[name] = []
            else:
                collections[name] = list(dict.fromkeys(str(gid) for gid in ids if str(gid) in valid_ids))
        return collections

    def create_collection(self):
        name = simpledialog.askstring("Create collection", "Name your collection:", parent=self)
        if name is None:
            return
        name = name.strip()
        if not name:
            messagebox.showinfo("Collection", "Please enter a collection name.", parent=self)
            return
        collections = self._collections()
        if any(existing.casefold() == name.casefold() for existing in collections):
            messagebox.showinfo("Collection exists", "A collection with that name already exists.", parent=self)
            return
        collections[name] = []
        self.save_settings()
        self.open_collections()

    def add_to_collection(self, game):
        collections = self._collections()
        if not collections:
            if messagebox.askyesno("Create a collection", "You don't have any collections yet. Create one now?", parent=self):
                name = simpledialog.askstring("New collection", "Name your collection:", parent=self)
                if not name or not name.strip():
                    return
                collections[name.strip()] = []
            else:
                return
        names = list(collections)
        prompt = "Enter a collection name:\n\n" + "\n".join(names) + "\n\nType an existing name, or enter a new name to create it:"
        choice = simpledialog.askstring("Add to Collection", prompt, parent=self)
        if not choice or not choice.strip():
            return
        choice = choice.strip()
        match = next((n for n in names if n.casefold() == choice.casefold()), None)
        if match is None:
            match = choice
            collections.setdefault(match, [])
        ids = collections[match]
        gid = str(game.get("id"))
        if gid not in ids:
            ids.append(gid)
        self.save_settings()
        self.status_label.configure(text=f"Added {game.get('name', 'game')} to {match}")

    def set_play_next(self, game):
        self.settings["play_next"] = str(game.get("id"))
        self.save_settings()
        self.render()
        if self.console_mode:
            self.render_console_games()

    def open_collections(self):
        win = ctk.CTkToplevel(self)
        win.title("Rocket Launcher — Collections")
        win.geometry("700x600")
        win.minsize(560, 460)
        win.configure(fg_color=BG)
        win.transient(self)
        win.grab_set()
        header = ctk.CTkFrame(win, fg_color="transparent")
        header.pack(fill="x", padx=20, pady=(18, 10))
        ctk.CTkLabel(header, text="YOUR COLLECTIONS", text_color=STAR,
                     font=self.make_font(size=22, weight="bold")).pack(side="left")
        ctk.CTkButton(header, text="＋ Create", width=110, command=lambda: (win.destroy(), self.create_collection())).pack(side="right")
        body = ctk.CTkScrollableFrame(win, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=18, pady=(0, 12))
        collections = self._collections()
        if not collections:
            ctk.CTkLabel(body, text="No collections yet. Create one, then use ADD TO COLLECTION on any game card.",
                         text_color=MUTED, wraplength=560).pack(padx=12, pady=35)
        play_id = str(self.settings.get("play_next") or "")
        play_game = next((g for g in self.games if str(g.get("id")) == play_id), None)
        next_frame = ctk.CTkFrame(body, fg_color="#1b2918", corner_radius=12, border_width=1, border_color=STAR)
        next_frame.pack(fill="x", padx=4, pady=(0, 12))
        ctk.CTkLabel(next_frame, text="▶  PLAY NEXT", text_color=STAR,
                     font=self.make_font(size=13, weight="bold")).pack(anchor="w", padx=12, pady=(10, 2))
        ctk.CTkLabel(next_frame, text=play_game.get("name") if play_game else "No game selected — click PLAY NEXT on a game card.",
                     text_color="#eef5e9", wraplength=560).pack(anchor="w", padx=12, pady=(0, 10))
        for name, ids in collections.items():
            frame = ctk.CTkFrame(body, fg_color=CARD_BG, corner_radius=12, border_width=1, border_color=BORDER)
            frame.pack(fill="x", padx=4, pady=5)
            valid_games = [g for g in self.games if str(g.get("id")) in ids]
            title = ctk.CTkFrame(frame, fg_color="transparent")
            title.pack(fill="x", padx=12, pady=(10, 2))
            ctk.CTkLabel(title, text=f"▤  {name}", text_color=STAR,
                         font=self.make_font(size=15, weight="bold")).pack(side="left")
            ctk.CTkLabel(title, text=f"{len(valid_games)} game(s)", text_color=MUTED).pack(side="right")
            game_names = ", ".join(g.get("name", "Untitled") for g in valid_games) or "Empty collection — use ADD TO COLLECTION on a game card."
            ctk.CTkLabel(frame, text=game_names, text_color="#e5ebdf", wraplength=600,
                         justify="left").pack(anchor="w", padx=14, pady=(2, 8))
            actions = ctk.CTkFrame(frame, fg_color="transparent")
            actions.pack(fill="x", padx=10, pady=(0, 10))
            ctk.CTkButton(actions, text="PLAY COLLECTION", height=30, command=lambda gs=valid_games: self.play_collection(gs)).pack(side="left", padx=(0, 6))
            ctk.CTkButton(actions, text="Rename", height=30, fg_color="#252d22", command=lambda n=name, w=win: self.rename_collection(n, w)).pack(side="left", padx=6)
            ctk.CTkButton(actions, text="Delete collection", height=30, fg_color="#4b2924", hover_color="#6b342b", command=lambda n=name, w=win: self.delete_collection(n, w)).pack(side="right")
        ctk.CTkButton(win, text="CLOSE", command=win.destroy, fg_color=ACCENT, hover_color=ACCENT_HOVER).pack(anchor="e", padx=20, pady=(0, 16))

    def play_collection(self, games):
        if not games:
            messagebox.showinfo("Empty collection", "Add games to this collection first.", parent=self)
            return
        game = next((g for g in games if str(g.get("id")) == str(self.settings.get("play_next"))), games[0])
        self.play(game)

    def rename_collection(self, old, win):
        new = simpledialog.askstring("Rename collection", "New collection name:", initialvalue=old, parent=win)
        if not new or not new.strip():
            return
        new = new.strip()
        collections = self._collections()
        if new != old and any(n.casefold() == new.casefold() for n in collections):
            messagebox.showinfo("Collection exists", "That collection name is already in use.", parent=win)
            return
        collections[new] = collections.pop(old)
        self.save_settings()
        win.destroy()
        self.open_collections()

    def delete_collection(self, name, win):
        if not messagebox.askyesno("Delete collection", f"Delete the collection '{name}'? Games will remain in your library.", parent=win):
            return
        self._collections().pop(name, None)
        self.save_settings()
        win.destroy()
        self.open_collections()

    def add_game(self):
        GameEditor(self, on_save=self.save_edited_game)

    def edit_game(self, game):
        GameEditor(self, game=game, on_save=self.save_edited_game)

    def save_edited_game(self, updated, original):
        if original is None:
            self.games.append(updated)
        else:
            index = self.games.index(original)
            self.games[index] = updated
            self.cover_cache.pop(original.get("id"), None)
        self.cover_cache.pop(updated.get("id"), None)
        if save_games(self.games, self):
            self.render()
            if not updated.get("cover") or not os.path.isfile(updated["cover"]):
                self.fetch_cover(updated)

    def open_game_folder(self, game):
        path = str(game.get("path", ""))
        if path.lower().startswith(("steam://", "com.epicgames.launcher://", "legendary://")):
            messagebox.showinfo("Store shortcut", "This entry opens a store launcher rather than a local executable, so it has no game folder here.", parent=self)
            return
        folder = os.path.dirname(path)
        if not folder or not os.path.isdir(folder):
            messagebox.showerror("Folder not found", f"The installation folder doesn't exist:\n{folder or path}", parent=self)
            return
        try:
            if os.name == "nt":
                os.startfile(folder)  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.Popen(["open", folder])
            else:
                subprocess.Popen(["xdg-open", folder])
        except Exception as exc:
            messagebox.showerror("Couldn't open folder", str(exc), parent=self)

    def remove_game(self, game):
        if game["id"] in self.running:
            messagebox.showinfo("Game is running", "Close the game before removing it.", parent=self)
            return
        if messagebox.askyesno("Remove game", f"Remove {game['name']} from your library?\nThe game files will not be deleted.", parent=self):
            self.games.remove(game)
            self.cover_cache.pop(game["id"], None)
            gid = str(game.get("id"))
            for collection_ids in self._collections().values():
                if gid in collection_ids:
                    collection_ids.remove(gid)
            if str(self.settings.get("play_next") or "") == gid:
                self.settings["play_next"] = None
            self.save_settings()
            if save_games(self.games, self):
                self.render()

    def fetch_cover(self, game):
        gid = game["id"]
        if gid in self.fetching:
            return
        self.fetching.add(gid)
        threading.Thread(target=self.cover_worker, args=(gid, game.get("name", "")), daemon=True).start()

    def cover_worker(self, gid, name):
        try:
            path = download_cover(name, gid)
        except Exception:
            path = None
        self.results.put((gid, name, path))

    def fetch_missing_covers(self):
        missing = [g for g in self.games if not (g.get("cover") and os.path.isfile(g["cover"]))]
        if not missing:
            messagebox.showinfo("Covers", "Every game already has a cover.", parent=self)
            return
        self.misses = []
        for game in missing:
            self.fetch_cover(game)

    def check_cover_results(self):
        changed = False
        while True:
            try:
                gid, name, path = self.results.get_nowait()
            except queue.Empty:
                break
            self.fetching.discard(gid)
            game = next((item for item in self.games if item["id"] == gid), None)
            if game and path:
                game["cover"] = path
                self.cover_cache.pop(gid, None)
                changed = True
            elif game:
                self.misses.append(name)
        if changed:
            save_games(self.games, self)
            self.render()
        if self.fetching:
            self.status_label.configure(text="Finding covers…")
        elif self.misses:
            self.status_label.configure(text=f"No cover found for {len(self.misses)} game(s); choose Edit to set one manually.")
        else:
            self.status_label.configure(text="")

    def open_uri(self, uri):
        try:
            if os.name == "nt":
                os.startfile(uri)  # type: ignore[attr-defined]
            else:
                webbrowser.open(uri)
        except Exception as exc:
            messagebox.showerror("Couldn't open launcher", f"Make sure the relevant launcher is installed.\n\n{exc}", parent=self)

    def play(self, game):
        gid, path = game["id"], str(game.get("path", ""))
        if gid in self.running:
            return
        if game.get("store") == "epic" and game.get("app_name"):
            if not game.get("installed", False):
                self.epic_install(game)
                return
            # If the local Epic manifest supplied a real executable, try it directly.
            # Otherwise use Legendary for the store-managed launch path.
            if not (path and os.path.isfile(path)):
                self.run_legendary(["launch", str(game["app_name"])], f"Launching {game.get('name', 'Epic game')}…")
                game["last_played"] = time.time()
                save_games(self.games, self)
                self.render()
                return
        if path.lower().startswith(("steam://", "com.epicgames.launcher://", "legendary://")):
            self.open_uri(path)
            game["last_played"] = time.time()
            save_games(self.games, self)
            self.render()
            return
        if not os.path.isfile(path):
            messagebox.showerror("Can't find game", f"This file no longer exists:\n{path}\n\nUse Edit to update its location.", parent=self)
            return
        try:
            # Preserve quoting for common Windows arguments; shlex supports quoted values.
            args = shlex.split(str(game.get("arguments", "")), posix=(os.name != "nt"))
            if os.name == "nt":
                args = [arg.strip('"') for arg in args]
            # Windows cannot execute .bat/.cmd files directly with CreateProcess.
            command = [path, *args]
            if os.name == "nt" and Path(path).suffix.casefold() in {".bat", ".cmd"}:
                command = [os.environ.get("COMSPEC", "cmd.exe"), "/c", path, *args]
            process = subprocess.Popen(command, cwd=os.path.dirname(path) or None)
        except Exception as exc:
            messagebox.showerror("Couldn't start game", str(exc), parent=self)
            return
        game["last_played"] = time.time()
        self.running[gid] = (process, time.monotonic())
        save_games(self.games, self)
        self.render()

    def legendary_path(self):
        configured = self.settings.get("legendary_path")
        candidates = [configured, str(BASE_DIR / "tools" / "legendary.exe"), shutil.which("legendary"), shutil.which("legendary.exe")]
        for candidate in candidates:
            if candidate and Path(candidate).is_file():
                return str(candidate)
        return None

    def open_store_hub(self):
        win = ctk.CTkToplevel(self)
        win.title("Rocket Launcher — Store Hub")
        win.geometry("650x560")
        win.minsize(590, 500)
        win.configure(fg_color=BG)
        win.transient(self)
        ctk.CTkLabel(win, text="☄  STORE HUB", font=self.make_font(size=25, weight="bold")).pack(anchor="w", padx=24, pady=(22, 4))
        ctk.CTkLabel(win, text="Connect through the official Steam client and Legendary for Epic.", text_color=MUTED, wraplength=590, justify="left").pack(anchor="w", padx=24, pady=(0, 18))
        steam = ctk.CTkFrame(win, fg_color=CARD_BG, corner_radius=12)
        steam.pack(fill="x", padx=20, pady=8)
        ctk.CTkLabel(steam, text="STEAM", font=self.make_font(size=16, weight="bold")).pack(anchor="w", padx=16, pady=(12, 3))
        ctk.CTkLabel(steam, text="Sign in using Steam itself. Rocket scans installed Steam games; installs open in Steam.", text_color=MUTED, wraplength=560, justify="left").pack(anchor="w", padx=16, pady=(0, 8))
        row = ctk.CTkFrame(steam, fg_color="transparent")
        row.pack(fill="x", padx=12, pady=(0, 12))
        ctk.CTkButton(row, text="Open Steam / Sign in", command=lambda: self.open_uri("steam://open/main")).pack(side="left", padx=4)
        ctk.CTkButton(row, text="Scan installed games", command=self.scan_steam_games).pack(side="left", padx=4)
        ctk.CTkButton(row, text="Install by App ID", command=self.install_steam_by_id).pack(side="left", padx=4)

        epic = ctk.CTkFrame(win, fg_color=CARD_BG, corner_radius=12)
        epic.pack(fill="x", padx=20, pady=8)
        ctk.CTkLabel(epic, text="EPIC GAMES · LEGENDARY", font=self.make_font(size=16, weight="bold")).pack(anchor="w", padx=16, pady=(12, 3))
        exe = self.legendary_path()
        ctk.CTkLabel(epic, text=(f"Legendary ready: {exe}" if exe else "Not installed yet. Rocket can download the Windows build from the official GitHub releases."), text_color=MUTED, wraplength=560, justify="left").pack(anchor="w", padx=16, pady=(0, 8))
        row2 = ctk.CTkFrame(epic, fg_color="transparent")
        row2.pack(fill="x", padx=12, pady=(0, 12))
        ctk.CTkButton(row2, text="Install / Update Legendary", command=self.install_legendary).pack(side="left", padx=4)
        ctk.CTkButton(row2, text="Choose EXE…", command=self.choose_legendary).pack(side="left", padx=4)
        ctk.CTkButton(row2, text="Epic sign in", command=self.epic_login).pack(side="left", padx=4)
        ctk.CTkButton(row2, text="Sync library", command=self.sync_epic_library).pack(side="left", padx=4)
        ctk.CTkLabel(win, text="Security: sign in only in Steam / Epic's official login flow. Rocket does not ask you to type store passwords into this app.", text_color="#a6ed6c", wraplength=590, justify="left").pack(anchor="w", padx=24, pady=(12, 0))
        ctk.CTkLabel(win, text="Note: Steam's full uninstalled account library is not exposed by local manifests. Scan shows installed games; App ID installs are handed to Steam.", text_color=MUTED, wraplength=590, justify="left").pack(anchor="w", padx=24, pady=(8, 16))

    def install_legendary(self):
        """Download the latest standalone Windows Legendary binary from its GitHub releases."""
        if os.name != "nt":
            messagebox.showinfo("Windows build", "Automatic setup currently downloads the Windows Legendary executable. On this platform, install Legendary using its official instructions.", parent=self)
            self.open_uri("https://github.com/derrod/legendary/releases")
            return
        tools_dir = BASE_DIR / "tools"
        target = tools_dir / "legendary.exe"
        self.status_label.configure(text="Downloading Legendary from official GitHub releases…")
        def worker():
            try:
                api = "https://api.github.com/repos/legendary-gl/legendary/releases/latest"
                request = urllib.request.Request(api, headers={"User-Agent": "RocketLauncher", "Accept": "application/vnd.github+json"})
                with urllib.request.urlopen(request, timeout=30) as response:
                    release = json.loads(response.read().decode("utf-8"))
                assets = release.get("assets", [])
                exe_assets = [a for a in assets if str(a.get("name", "")).lower().endswith(".exe") and a.get("browser_download_url")]
                if not exe_assets:
                    raise RuntimeError("No Windows .exe asset was found in the latest official Legendary release. Open the releases page and choose the Windows executable manually.")
                def rank(asset):
                    name = str(asset.get("name", "")).lower()
                    score = 0
                    if "windows" in name or "win" in name: score += 5
                    if "x86_64" in name or "x64" in name or "amd64" in name: score += 4
                    if "legendary" in name: score += 1
                    return score
                asset = sorted(exe_assets, key=rank, reverse=True)[0]
                tools_dir.mkdir(parents=True, exist_ok=True)
                request = urllib.request.Request(asset["browser_download_url"], headers={"User-Agent": "RocketLauncher"})
                temp = target.with_suffix(".download")
                with urllib.request.urlopen(request, timeout=90) as response, open(temp, "wb") as out:
                    shutil.copyfileobj(response, out)
                if temp.stat().st_size < 100_000:
                    temp.unlink(missing_ok=True)
                    raise RuntimeError("The downloaded file was unexpectedly small; it was not installed.")
                temp.replace(target)
                self.store_results.put(("legendary_download", str(target), release.get("tag_name", "latest")))
            except Exception as exc:
                self.store_results.put(("legendary_download_error", str(exc)))
        threading.Thread(target=worker, daemon=True).start()

    def choose_legendary(self):
        path = filedialog.askopenfilename(parent=self, title="Choose Legendary executable", filetypes=[("Legendary executable", "legendary.exe"), ("Programs", "*.exe"), ("All files", "*.*")])
        if path:
            self.settings["legendary_path"] = path
            self.save_settings()
            messagebox.showinfo("Legendary configured", "Legendary executable saved. You can now sign in or sync your Epic library.", parent=self)

    def run_legendary(self, args, status):
        exe = self.legendary_path()
        if not exe:
            messagebox.showwarning("Legendary required", "Install Legendary or select legendary.exe in Store Hub first. The official project is https://github.com/derrod/legendary/releases", parent=self)
            return
        self.status_label.configure(text=status)
        def worker():
            try:
                creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
                proc = subprocess.run([exe, *args], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60*60, creationflags=creationflags)
                self.store_results.put(("command", args, proc.returncode, proc.stdout, proc.stderr))
            except Exception as exc:
                self.store_results.put(("error", args, 1, "", str(exc)))
        threading.Thread(target=worker, daemon=True).start()

    def epic_login(self):
        exe = self.legendary_path()
        if not exe:
            messagebox.showwarning("Legendary required", "Choose or install legendary.exe first.", parent=self)
            return
        try:
            # Interactive auth should have its own visible console on Windows.
            if os.name == "nt":
                subprocess.Popen([exe, "auth"], creationflags=subprocess.CREATE_NEW_CONSOLE)
            else:
                subprocess.Popen([exe, "auth"])
            messagebox.showinfo("Epic sign-in started", "Complete the Epic authentication flow opened by Legendary. When it finishes, return to Store Hub and click Sync Epic library.", parent=self)
        except Exception as exc:
            messagebox.showerror("Epic sign-in failed", str(exc), parent=self)

    def _decode_json_output(self, output):
        output = (output or "").strip()
        # Legendary may print logs before JSON; locate the first JSON array/object.
        starts = [i for i in (output.find("["), output.find("{")) if i >= 0]
        decoder = json.JSONDecoder()
        for start, char in enumerate(output):
            if char not in "[{":
                continue
            try:
                value, _end = decoder.raw_decode(output[start:])
                return value
            except json.JSONDecodeError:
                continue
        raise ValueError("Legendary did not return valid JSON. Check the Legendary version and login state.")

    def sync_epic_library(self):
        self.run_legendary(["list", "--json"], "Syncing Epic library…")

    def _merge_epic_games(self, output):
        data = self._decode_json_output(output)
        if isinstance(data, dict):
            data = data.get("games", data.get("items", list(data.values()) if all(isinstance(v, dict) for v in data.values()) else []))
        if not isinstance(data, list):
            raise ValueError("Unexpected Epic library response format.")
        existing = {str(g.get("app_name")): g for g in self.games if g.get("store") == "epic"}
        imported = 0
        for item in data:
            if not isinstance(item, dict):
                continue
            app_name = str(item.get("app_name") or item.get("appName") or item.get("name") or "").strip()
            title = str(item.get("title") or item.get("app_title") or item.get("name") or app_name).strip()
            if not app_name:
                continue
            game = existing.get(app_name)
            if game:
                game["name"] = title or game["name"]
            else:
                game = {"id": "epic-" + app_name, "name": title or app_name, "path": "legendary://" + app_name, "arguments": "", "cover": None, "seconds": 0, "last_played": None, "store": "epic", "app_name": app_name, "installed": False}
                self.games.append(game)
                imported += 1
        if not save_games(self.games, self):
            return
        self.render()
        self.status_label.configure(text=f"Epic library synced · {len(data)} entries · {imported} added")
        messagebox.showinfo("Epic library synced", f"Imported/updated Epic library. {imported} new game(s) added. Games can be installed from their cards.", parent=self)

    def _mark_epic_installed(self, output):
        data = self._decode_json_output(output)
        if isinstance(data, dict):
            data = data.get("games", data.get("items", list(data.values()) if all(isinstance(v, dict) for v in data.values()) else []))
        installed = set()
        if isinstance(data, list):
            for item in data:
                if isinstance(item, dict):
                    key = str(item.get("app_name") or item.get("appName") or item.get("name") or "").strip()
                    if key:
                        installed.add(key)
        for game in self.games:
            if game.get("store") == "epic":
                game["installed"] = str(game.get("app_name")) in installed
        save_games(self.games, self)
        self.render()
        self.status_label.configure(text=f"Epic sync complete · {len(installed)} installed")

    def epic_install(self, game):
        folder = filedialog.askdirectory(parent=self, title="Choose Epic game install folder")
        if not folder:
            return
        app_name = str(game.get("app_name") or game.get("name"))
        self.status_label.configure(text=f"Installing {game['name']} with Legendary…")
        exe = self.legendary_path()
        if not exe:
            messagebox.showwarning("Legendary required", "Choose or install legendary.exe first.", parent=self)
            return
        def worker():
            try:
                creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
                # -y answers Legendary confirmation prompts; --skip-sdl and --skip-dlcs
                # prevent hidden GUI installs from waiting forever for terminal input.
                command = [exe, "-y", "install", app_name, "--base-path", folder,
                           "--skip-sdl", "--skip-dlcs"]
                process = subprocess.Popen(
                    command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    text=True, encoding="utf-8", errors="replace", bufsize=1,
                    creationflags=creationflags
                )
                output_lines = []
                if process.stdout:
                    for line in process.stdout:
                        clean = line.strip()
                        if clean:
                            output_lines.append(clean)
                            self.store_results.put(("install_progress", game["id"], clean[-220:]))
                code = process.wait()
                output = "\\n".join(output_lines)
                self.store_results.put(("install", game["id"], code, output, "", folder))
            except Exception as exc:
                self.store_results.put(("error", ["install", app_name], 1, "", str(exc)))
        threading.Thread(target=worker, daemon=True).start()

    def check_store_results(self):
        while True:
            try:
                result = self.store_results.get_nowait()
            except queue.Empty:
                break
            kind = result[0]
            if kind == "install_progress":
                _, gid, line = result
                game = next((g for g in self.games if g.get("id") == gid), None)
                if game:
                    self.status_label.configure(text=f"Installing {game.get('name', 'Epic game')}: {line}")
            elif kind == "legendary_download":
                _, exe_path, version = result
                self.settings["legendary_path"] = exe_path
                self.save_settings()
                self.status_label.configure(text=f"Legendary {version} installed")
                messagebox.showinfo("Legendary ready", f"Legendary {version} is installed. Click Epic sign in, finish authentication, then Sync library.", parent=self)
            elif kind == "legendary_download_error":
                messagebox.showerror("Could not install Legendary", f"{result[1]}\n\nYou can open the official releases page and choose the Windows executable manually.", parent=self)
                self.open_uri("https://github.com/derrod/legendary/releases")
                self.status_label.configure(text="Legendary setup needs attention")
            elif kind == "command":
                _, args, code, stdout, stderr = result
                if code == 0 and args[:1] == ["list"]:
                    try:
                        self._merge_epic_games(stdout)
                        self.run_legendary(["list-installed", "--json"], "Checking installed Epic games…")
                    except Exception as exc:
                        messagebox.showerror("Epic sync failed", f"Could not read Legendary output.\n\n{exc}\n\n{(stderr or stdout)[-2500:]}", parent=self)
                elif code == 0 and args[:1] == ["list-installed"]:
                    try:
                        self._mark_epic_installed(stdout)
                    except Exception as exc:
                        messagebox.showwarning("Installed games", f"Epic library synced, but installed status could not be read.\n\n{exc}", parent=self)
                elif code != 0:
                    messagebox.showerror("Legendary command failed", f"Command: {' '.join(args)}\n\n{(stderr or stdout or 'No details returned.')[-2500:]}", parent=self)
                else:
                    self.status_label.configure(text="Legendary command completed.")
            elif kind == "install":
                _, gid, code, stdout, stderr, folder = result
                game = next((g for g in self.games if g.get("id") == gid), None)
                if code == 0 and game:
                    game["installed"] = True
                    game["install_dir"] = folder
                    game["path"] = "legendary://" + str(game.get("app_name") or game["name"])
                    save_games(self.games, self)
                    self.render()
                    messagebox.showinfo("Install complete", f"{game['name']} installed. Press LAUNCH to start it.", parent=self)
                else:
                    messagebox.showerror("Install failed", f"{(stderr or stdout or 'Legendary did not provide details.')[-2500:]}", parent=self)
            elif kind == "error":
                messagebox.showerror("Store command failed", str(result[-1]), parent=self)
                self.status_label.configure(text="Store command failed.")

    def find_steam_exe(self):
        candidates = []
        for env in (os.environ.get("PROGRAMFILES(X86)"), os.environ.get("PROGRAMFILES"),
                    os.environ.get("PROGRAMW6432"), os.environ.get("LOCALAPPDATA")):
            if env:
                candidates.extend([Path(env) / "Steam" / "steam.exe", Path(env) / "steam" / "steam.exe"])
        if os.name == "nt":
            try:
                import winreg
                for hive, key_name in [
                    (winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam"),
                    (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam"),
                    (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Valve\Steam")]:
                    try:
                        with winreg.OpenKey(hive, key_name) as key:
                            for value_name in ("SteamPath", "InstallPath"):
                                try:
                                    value, _ = winreg.QueryValueEx(key, value_name)
                                    candidates.append(Path(value) / "steam.exe")
                                except OSError: pass
                    except OSError: pass
            except ImportError: pass
        for candidate in candidates:
            if candidate.is_file(): return candidate
        return None

    def steam_library_paths(self):
        steam_exe = self.find_steam_exe()
        if not steam_exe: return []
        root = steam_exe.parent
        paths = [root]
        vdf = root / "steamapps" / "libraryfolders.vdf"
        if vdf.exists():
            try:
                content = vdf.read_text(encoding="utf-8", errors="ignore")
                raw_paths = re.findall(r'"path"\s*"([^"]+)"', content)
                raw_paths += re.findall(r'"\d+"\s*"([A-Za-z]:\\\\[^"]+)"', content)
                for raw in raw_paths:
                    lib = Path(raw.replace("\\\\", "\\"))
                    if lib.exists() and all(str(lib).casefold() != str(x).casefold() for x in paths):
                        paths.append(lib)
            except OSError: pass
        for drive in "CDEFGHIJKLMNOPQRSTUVWXYZ":
            for candidate in (Path(f"{drive}:") / "SteamLibrary", Path(f"{drive}:") / "Games" / "SteamLibrary"):
                if (candidate / "steamapps").is_dir() and all(str(candidate).casefold() != str(x).casefold() for x in paths):
                    paths.append(candidate)
        return paths

    def scan_steam_games(self, silent=False):
        added = 0
        libraries = self.steam_library_paths()
        known = {str(g.get("appid")): g for g in self.games if g.get("store") == "steam" and g.get("appid")}
        for library in libraries:
            apps = library / "steamapps"
            if not apps.is_dir(): continue
            for manifest in apps.glob("appmanifest_*.acf"):
                try:
                    content = manifest.read_text(encoding="utf-8", errors="ignore")
                    appid = re.search(r'"appid"\s*"(\d+)"', content)
                    name = re.search(r'"name"\s*"([^"]+)"', content)
                    installdir = re.search(r'"installdir"\s*"([^"]+)"', content)
                    if not appid or not name: continue
                    aid, title = appid.group(1), name.group(1)
                    install_dir = apps / "common" / (installdir.group(1) if installdir else title)
                    if aid in known:
                        known[aid].update({"installed": True, "install_dir": str(install_dir),
                                           "path": f"steam://rungameid/{aid}"})
                        continue
                    game = {"id": "steam-" + aid, "name": title, "path": f"steam://rungameid/{aid}",
                            "arguments": "", "cover": None, "seconds": 0, "last_played": None,
                            "store": "steam", "appid": aid, "installed": True, "install_dir": str(install_dir)}
                    self.games.append(game); known[aid] = game; added += 1
                except OSError: continue
        if added or libraries:
            save_games(self.games, self)
            self.render()
        if not silent:
            messagebox.showinfo("Steam scan complete",
                f"Scanned {len(libraries)} Steam library location(s). Added {added} new installed game(s).", parent=self)
        return added, len(libraries)

    def scan_epic_installed_games(self):
        dirs = []
        if os.environ.get("PROGRAMDATA"):
            dirs.append(Path(os.environ["PROGRAMDATA"]) / "Epic" / "EpicGamesLauncher" / "Data" / "Manifests")
        if os.environ.get("LOCALAPPDATA"):
            local = Path(os.environ["LOCALAPPDATA"])
            dirs.extend([local / "EpicGamesLauncher" / "Saved" / "Manifests",
                         local / "EpicGamesLauncher" / "Saved" / "Config" / "Windows"])
        dirs = [d for d in dirs if d.is_dir()]
        known = {str(g.get("app_name") or "").casefold(): g for g in self.games if g.get("store") == "epic"}
        added = 0
        updated = False
        for folder in dirs:
            for manifest in folder.glob("*.item"):
                try:
                    data = json.loads(manifest.read_text(encoding="utf-8-sig", errors="replace"))
                    app_name = str(data.get("AppName") or data.get("CatalogItemId") or "").strip()
                    title = str(data.get("DisplayName") or data.get("AppName") or app_name).strip()
                    install_dir = str(data.get("InstallLocation") or "").strip()
                    if not app_name or not install_dir or not Path(install_dir).is_dir(): continue
                    if app_name.casefold() in known:
                        existing = known[app_name.casefold()]
                        new_values = {"installed": True, "install_dir": install_dir, "app_name": app_name}
                        if any(existing.get(key) != value for key, value in new_values.items()):
                            existing.update(new_values)
                            updated = True
                        continue
                    launch_exe = str(data.get("LaunchExecutable") or "").replace("/", os.sep).strip()
                    exe = Path(install_dir) / launch_exe if launch_exe else None
                    game = {"id": "epic-" + app_name, "name": title,
                            "path": str(exe) if exe and exe.is_file() else "com.epicgames.launcher://apps/" + app_name + "?action=launch&silent=true",
                            "arguments": str(data.get("LaunchCommand") or ""), "cover": None,
                            "seconds": 0, "last_played": None, "store": "epic", "app_name": app_name,
                            "installed": True, "install_dir": install_dir}
                    self.games.append(game); known[app_name.casefold()] = game; added += 1
                except (OSError, json.JSONDecodeError, TypeError, ValueError): continue
        if updated:
            save_games(self.games, self)
        return added, len(dirs)

    def auto_scan_installed_games(self):
        self.status_label.configure(text="SCANNING PC FOR STEAM & EPIC GAMES…")
        try: steam_added, steam_locations = self.scan_steam_games(silent=True)
        except Exception: steam_added, steam_locations = 0, 0
        try: epic_added, epic_locations = self.scan_epic_installed_games()
        except Exception: epic_added, epic_locations = 0, 0
        if steam_added or epic_added:
            save_games(self.games, self)
            self.render()
        if steam_locations == 0 and epic_locations == 0:
            self.status_label.configure(text="AUTO-SCAN COMPLETE • No Steam/Epic install manifests found")
        else:
            self.status_label.configure(text=f"AUTO-SCAN COMPLETE • Steam +{steam_added} • Epic +{epic_added} • Existing games kept")

    def install_steam_by_id(self):
        appid = simpledialog.askstring("Install Steam game", "Enter the game's Steam App ID (numbers only):", parent=self)
        if not appid:
            return
        appid = appid.strip()
        if not appid.isdigit():
            messagebox.showwarning("Invalid App ID", "Steam App ID must contain digits only.", parent=self)
            return
        self.open_uri(f"steam://install/{appid}")
        if not any(g.get("store") == "steam" and str(g.get("appid")) == appid for g in self.games):
            title = simpledialog.askstring("Add Steam game", "Optional: enter a game title to show in Rocket Launcher:", parent=self) or f"Steam game {appid}"
            self.games.append({"id": "steam-" + appid, "name": title, "path": f"steam://rungameid/{appid}", "arguments": "", "cover": None, "seconds": 0, "last_played": None, "store": "steam", "appid": appid, "installed": False})
            save_games(self.games, self)
            self.render()

    def set_wallpaper(self):
        path = filedialog.askopenfilename(parent=self, title="Choose launcher wallpaper", filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.bmp")])
        if not path:
            return
        try:
            with Image.open(path) as image:
                image.verify()
            self.settings["wallpaper"] = path
            self.save_settings()
            if self.wallpaper_label:
                self.wallpaper_label.destroy()
            self.wallpaper_image = None
            self._apply_wallpaper()
            # Keep UI content above the wallpaper while allowing transparent frames to show it.
            self.wallpaper_label.lower()
        except Exception as exc:
            messagebox.showerror("Wallpaper error", f"That image couldn't be loaded.\n\n{exc}", parent=self)

    def clear_wallpaper(self):
        self.settings.pop("wallpaper", None)
        self.save_settings()
        if self.wallpaper_label:
            self.wallpaper_label.destroy()
            self.wallpaper_label = None
            self.wallpaper_image = None

    def check_running(self):
        changed = False
        now = time.monotonic()
        for gid, (process, start) in list(self.running.items()):
            game = next((item for item in self.games if item["id"] == gid), None)
            if process.poll() is not None:
                self.running.pop(gid, None)
                if game:
                    game["seconds"] = game.get("seconds", 0) + max(0, now - start)
                changed = True
            elif now - start >= 30:
                if game:
                    game["seconds"] = game.get("seconds", 0) + (now - start)
                self.running[gid] = (process, now)
                changed = True
        if changed:
            save_games(self.games, self)
            self.render()

    def tick(self):
        self.check_running()
        self.check_cover_results()
        self.check_store_results()
        self.after(500, self.tick)

    def on_close(self):
        now = time.monotonic()
        for gid, (_, start) in list(self.running.items()):
            game = next((item for item in self.games if item["id"] == gid), None)
            if game:
                game["seconds"] = game.get("seconds", 0) + max(0, now - start)
        save_games(self.games, self)
        self.destroy()


if __name__ == "__main__":
    try:
        Launcher().mainloop()
    except Exception as exc:
        # If startup fails in a packaged build, leave a readable error rather than silently closing.
        try:
            messagebox.showerror(APP_NAME, f"Rocket Launcher could not start.\n\n{exc}")
        except Exception:
            print(f"{APP_NAME} startup error: {exc}", file=sys.stderr)
        raise
