\
    @echo off
    setlocal
    cd /d "%~dp0"
    title Rocket Launcher

    set PYTHON=python
    where py >nul 2>nul
    if %errorlevel%==0 (
        py -3.15 -c "import sys" >nul 2>nul
        if not errorlevel 1 (
            set PYTHON=py -3.15
        ) else (
            set PYTHON=py -3
        )
    )

    %PYTHON% -c "import customtkinter, PIL" >nul 2>nul
    if errorlevel 1 (
        echo Installing Rocket Launcher requirements...
        %PYTHON% -m pip install -r requirements_launcher.txt
        if errorlevel 1 goto :error
    )

    %PYTHON% rocket_launcher.py
    if errorlevel 1 goto :error
    goto :eof

    :error
    echo.
    echo Rocket Launcher could not start. Check the error above.
    pause
