ROCKET LAUNCHER - BUILD A WINDOWS EXE

REQUIREMENTS
- Windows 10 or 11, 64-bit
- Python 3.15.2 64-bit installed
- During Python setup, enable the Python Launcher (py command)
- Internet connection for the first build (to install packages)

BUILD
1. Extract this entire ZIP to a normal folder, for example Desktop\RocketLauncher.
2. Keep all included files together. Do not run the BAT from inside the ZIP preview.
3. Double-click build_rocket_launcher.bat.
4. Wait for the build to finish. The EXE will be:
   dist\Rocket Launcher.exe

RUN / MOVE TO ANOTHER PC
- Copy "Rocket Launcher.exe" to a folder where you want to keep the launcher.
- Copy your existing games.json into that same folder (if you have one).
- Keep the EXE in that folder so it can save games.json, covers and settings there.
- The Python runtime and required Python packages are bundled in the EXE.

NOTES
- This creates a single-file EXE, not an installer. It does not automatically create a desktop shortcut.
- Windows EXEs must be built on Windows; this ZIP contains the source and build script.
- Epic game downloads still use the Legendary tool as configured by the launcher; the EXE packages the launcher, not Legendary itself.
- Controller support is included through pygame-ce. If the build reports a missing pygame module, send the complete error text.
- Do not delete the original source ZIP or games.json backup until you have tested the EXE.
