@echo off
setlocal
cd /d "%~dp0"
title Build Rocket Launcher EXE

echo ==========================================
echo        ROCKET LAUNCHER - EXE BUILDER
echo ==========================================
echo.

where py >nul 2>nul
if errorlevel 1 (
  echo ERROR: Python Launcher was not found.
  echo Install Python 3.15.2 64-bit, then reopen this file.
  pause
  exit /b 1
)

py -3.15 --version
if errorlevel 1 (
  echo ERROR: Python 3.15 was not found.
  echo Install Python 3.15.2 64-bit and enable the Python Launcher.
  pause
  exit /b 1
)

echo.
echo [1/3] Updating pip and installing launcher/build packages...
py -3.15 -m pip install --upgrade pip
if errorlevel 1 goto :error
py -3.15 -m pip install -r requirements_launcher.txt -r requirements_controller.txt --upgrade
if errorlevel 1 goto :error
py -3.15 -m pip install --upgrade pyinstaller
if errorlevel 1 goto :error

echo.
echo [2/3] Building the standalone Windows EXE...
py -3.15 -m PyInstaller --noconfirm --clean --windowed --onefile ^
  --name "Rocket Launcher" ^
  --icon "rocket_launcher.ico" ^
  --collect-all customtkinter ^
  --collect-all pygame ^
  --add-data "rocket_launcher_icon.png;." ^
  --add-data "rocket_launcher.ico;." ^
  rocket_launcher.py
if errorlevel 1 goto :error

echo.
echo [3/3] Build finished!
echo Your EXE is here:
echo %CD%\dist\Rocket Launcher.exe
echo.
echo IMPORTANT: Copy your existing games.json into the same folder as the EXE.
echo The launcher stores games.json, covers and settings beside the EXE.
echo.
pause
exit /b 0

:error
echo.
echo BUILD FAILED. Copy the error text above and send it to ChatGPT.
pause
exit /b 1
